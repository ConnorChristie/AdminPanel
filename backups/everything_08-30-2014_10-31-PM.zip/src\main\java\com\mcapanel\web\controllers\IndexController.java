package com.mcapanel.web.controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.Lock;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.mcapanel.bukkit.utils.HtmlEscape;
import com.mcapanel.panel.AdminPanelWrapper;
import com.mcapanel.web.database.User;
import com.mcapanel.web.handlers.Controller;

public class IndexController extends Controller
{
	public void index() throws IOException
	{
		if (request.getAttribute("tabs") == null)
			request.setAttribute("tabs", getTabs());
		
		Object includeSidebar = request.getAttribute("includeSidebar");
		
		if (includeSidebar != null && (Boolean) includeSidebar)
			setOnlinePlayers();
		
		request.setAttribute("chats", getChats());
		
		if (isLoggedIn() && user.getGroup().hasPermission("console"))
			request.setAttribute("console", getConsole());
	}
	
	private List<String> getTabs()
	{
		List<String> tabs = new ArrayList<String>();
		
		tabs.add("home");
		
		if (isLoggedIn())
		{
			boolean noPerm = false;
			
			if (ap.getPluginConnector().connected())
				tabs.add("players");
			
			if (user.getGroup().hasPermission("plugins"))
				tabs.add("plugins");
			else
				noPerm = true;
			
			if (user.getGroup().hasPermission("backups"))
				tabs.add("backups");
			else
				noPerm = true;
			
			if (user.getGroup().hasPermission("applications"))
				tabs.add("applications");
			else
				noPerm = true;
			
			if (ap.hasDynmap())
				tabs.add("dynmap");
			
			if (user.getGroup().hasPermission("webusers"))
			{
				List<String> webTabs = new ArrayList<String>();
				
				webTabs.add("users");
				webTabs.add("groups");
				
				request.setAttribute("webTabs", webTabs);
			} else
				noPerm = true;
			
			if (user.getGroup().hasPermission("settings"))
				tabs.add("settings");
			
			if (noPerm)
			{
				tabs.add("about");
				tabs.add("contact");
			}
		} else
		{
			if (ap.getPluginConnector().connected())
				tabs.add("players");
			
			if (ap.hasDynmap())
				tabs.add("dynmap");
			
			tabs.add("about");
			tabs.add("contact");
		}
		
		return tabs;
	}
	
	protected static String getChats()
	{
		String chats = AdminPanelWrapper.getInstance().getPluginConnector().sendMethodResponse("getChats");
		
		return chats != null ? chats : "No Chats";
	}
	
	protected static String getConsole()
	{
		String console = "";
		
		final Lock lock = AdminPanelWrapper.getInstance().getConsoleLock().readLock();
		lock.lock();
		
		try
		{
			List<String> list = AdminPanelWrapper.getInstance().getConsole();
			
			int s = list.size() - 200;
			
			for (int i = (s < 0 ? 0 : s); i < list.size(); i++)
			{
				console += list.get(i);
			}
		} finally
		{
			lock.unlock();
		}
		
		console = HtmlEscape.escape(console);
		
		console = console.replace("WARN]:", "<span style='color: orange;'>WARN</span>]:");
		console = console.replace("ERROR]:", "<span style='color: red;'>ERROR</span>]:");
		
		if (console.isEmpty()) console = "No Console Data";
		
		return console;
	}
	
	private void setOnlinePlayers()
	{
		JSONObject obj = getOnlinePlayers();
		
		request.setAttribute("status", obj.get("status"));
		request.setAttribute("plist", obj.get("plist"));
		
		request.setAttribute("online", obj.get("online"));
		request.setAttribute("total", obj.get("total"));
	}
	
	@SuppressWarnings("unchecked")
	protected static JSONObject getOnlinePlayers()
	{
		JSONObject out = new JSONObject();
		
		String plist = "";
		String pret = AdminPanelWrapper.getInstance().getPluginConnector().sendMethodResponse("getOnlinePlayers");
		
		long online = 0;
		long total = 0;
		
		if (pret != null)
		{
			try
			{
				JSONObject obj = (JSONObject) new JSONParser().parse(pret);
				
				String playersStr = (String) obj.get("players");
				
				if (playersStr.length() != 0)
				{
					String[] players = playersStr.split(";");
					
					for (String p : players)
					{
						String[] ps = p.split("\\|");
						
						//Change to UUID
						User user = AdminPanelWrapper.getInstance().getDatabase().find(User.class).where().ieq("username", ps[0]).findUnique();
						
						plist += "<tr>";
						plist += "<td><img style=\"margin-top: 4px; margin-left: 4px;\" src=\"https://minotar.net/helm/" + ps[0] + "/15\" /></td>";
						plist += "<td>" + ps[0] + "</td>";
						plist += "<td>" + (user != null ? user.getGroup().getGroupName() : "Not Registered") + "</td>";
						plist += "<td>" + ps[1] + "</td>";
						plist += "</tr>";
					}
				}
				
				online = (Long) obj.get("online");
				total = (Long) obj.get("total");
			} catch (ParseException e) { }
			
			out.put("status", "<span style=\"color: #00A72F;\">Online</span>");
		} else
		{
			online = 0;
			total = 0;
			
			out.put("status", "<span style=\"color: red;\">Offline</span>");
		}
		
		out.put("plist", plist);
		
		out.put("online", online);
		out.put("total", total);
		
		return out;
	}
}