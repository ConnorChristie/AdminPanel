package com.mcapanel.license;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.mcapanel.panel.AdminPanelWrapper;
import com.mcapanel.utils.Utils;

import net.java.truelicense.obfuscate.ObfuscatedString;

public class LicenseManager
{
	private AdminPanelWrapper ap;
	
	private ObfuscatedString licemail = new ObfuscatedString(new long[] {-7919322956634818094L, -7105713148411355349L, 8843054321854713275L});
	private ObfuscatedString lickey = new ObfuscatedString(new long[] {-4547448912488374741L, -4620380974885930861L, 5513430613636552785L});
	
	private ObfuscatedString args = new ObfuscatedString(new long[] {8704636283140706353L, 5981060135283334031L, -6934586613514655188L});
	private ObfuscatedString args2 = new ObfuscatedString(new long[] {-1343397929172576624L, -4859719419406191387L, -8941892595073840353L});
	
	private ObfuscatedString server = new ObfuscatedString(new long[] {-7234663213394954967L, -1205641069827615805L, 7538256371896819258L, 8084463411839463574L, 8580805411995875718L, -7004656770141352461L, 7115656004602442724L});
	
	//status
	private ObfuscatedString statuss = new ObfuscatedString(new long[] {-951115222670284976L, 918907984356297171L});
	//message
	private ObfuscatedString messages = new ObfuscatedString(new long[] {2392282214464593035L, -6697780788665214669L});
	//success
	private ObfuscatedString success = new ObfuscatedString(new long[] {-247140708290822382L, 6701078725417091147L});
	//error
	private ObfuscatedString error = new ObfuscatedString(new long[] {5915991352329617607L, 556650394089241282L});
	//macrequest
	private ObfuscatedString macrequest = new ObfuscatedString(new long[] {6012059063833999218L, -5494862561367240867L, -540198388887897856L});
	//product
	private ObfuscatedString products = new ObfuscatedString(new long[] {7341511474020451619L, 2700101860230522540L});
	
	//Mac address request
	private ObfuscatedString macreq = new ObfuscatedString(new long[] {-2412813912961334917L, 3227296487188577860L, -3778439679571391880L, 7570886276883385805L});
	//Mac addresses updated
	private ObfuscatedString macup = new ObfuscatedString(new long[] {-3866703390584919143L, 1672752271012390905L, 6885187177977076170L, -6569001576792506287L});
	
	//Authenticated license
	private ObfuscatedString authed = new ObfuscatedString(new long[] {9155818419018198390L, -4955169058200578894L, 6068168706804651113L, -7002821465930990123L});
	//Could not connect
	private ObfuscatedString connect = new ObfuscatedString(new long[] {-8712797265917642042L, -336556830873465436L, -3974707958780934879L, -8378170709055609043L, 1298477908172791935L, -3466093537221664473L});
	
	private List<String> macs = new ArrayList<String>();
	
	private int product = 0;
	private boolean activated = false;
	
	public LicenseManager()
	{
		ap = AdminPanelWrapper.getInstance();
		
		try
		{
			Enumeration<NetworkInterface> nis = NetworkInterface.getNetworkInterfaces();
			
			while (nis.hasMoreElements())
			{
				NetworkInterface ni = nis.nextElement();
				
				byte[] mac = ni.getHardwareAddress();
				
				if (mac != null && mac.length > 2)
				{
					StringBuilder sb = new StringBuilder();
					
					for (int i = 0; i < mac.length; i++)
					{
						sb.append(String.format("%02X%s", mac[i], (i < mac.length - 1) ? "-" : ""));		
					}
					
					String macAddr = sb.toString();
					
					if (!macAddr.startsWith("00-"))
					{
						macs.add(macAddr);
					}
				}
			}
		} catch (SocketException e) { }
		
		if (macs.size() == 0)
		{
			System.out.println("Could not connect to license server...");
			
			System.exit(-1);
		}
		
		authenticateLicense();
	}
	
	public boolean isEvaluation()
	{
		return !activated || product == 0;
	}
	
	private void authenticateLicense()
	{
		String email = ap.getConfig().getString(licemail.toString(), "");
		String productKey = ap.getConfig().getString(lickey.toString(), "");
		
		String md5s = "";
		
		for (int i = 0; i < macs.size(); i++)
		{
			md5s += (i != 0 ? "," : "") + Utils.md5(email + productKey + macs.get(i));
		}
		
		sendRequest(args.toString().replace("%1", email).replace("%2", productKey).replace("%3", md5s));
	}
	
	private void sendRequest(String arguments)
	{
		String email = ap.getConfig().getString(licemail.toString(), "");
		String productKey = ap.getConfig().getString(lickey.toString(), "");
		
		try
		{
			URLConnection connection = new URL(server.toString()).openConnection();
			
			connection.setDoOutput(true);
			connection.setDoInput(true);
			
			OutputStreamWriter wr = new OutputStreamWriter(connection.getOutputStream());
			
			wr.write(arguments);
			wr.flush();
			
			BufferedReader rr = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			
			String line = rr.readLine();
			
			System.out.println(line);

			if (line != null)
			{
				JSONObject ret = (JSONObject) new JSONParser().parse(line);
				
				if (ret != null && ret.containsKey(statuss.toString()) && ret.containsKey(messages.toString()))
				{
					System.out.println("Test: " + getStr(ret.get("test")));
					
					String status = (String) ret.get(statuss.toString());
					String message = (String) ret.get(messages.toString());
					
					if (status.equals(macrequest.toString()) && message.equals(macreq.toString()))
					{
						String macAddrs = "";
						
						for (int i = 0; i < macs.size(); i++)
						{
							macAddrs += (i != 0 ? "," : "") + macs.get(i);
						}
						
						sendRequest(args2.toString().replace("%1", email).replace("%2", productKey).replace("%3", macAddrs));
					} else if (status.equals(success.toString()))
					{
						if (message.equals(macup.toString()))
						{
							authenticateLicense();
						} else if (message.equals(authed.toString()) && ret.containsKey(products.toString()))
						{
							//Authed license
							
							product = Integer.parseInt(ret.get(products.toString()).toString());
							
							activated = true;
						}
					} else if (status.equals(error.toString()))
					{
						product = 0;
						
						activated = false;
					}
				} else
					throw new Exception();
			} else
				throw new Exception();
			
			wr.close();
			rr.close();
		} catch (Exception e) { System.out.println("Could not connect to license server..."); System.exit(-1); }
	}
	
	private String getStr(Object o)
	{
		JSONArray array = (JSONArray) o;
		
		long[] longs = new long[array.size()];
		
		for (int i = 0; i < array.size(); i++)
		{
			longs[i] = (Long) array.get(i);
		}
		
		return new ObfuscatedString(longs).toString();
	}
}