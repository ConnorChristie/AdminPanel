$(function() {
	$("#usertable").dataTable({
		"bLengthChange": false,
		stateSave: true
	});
});