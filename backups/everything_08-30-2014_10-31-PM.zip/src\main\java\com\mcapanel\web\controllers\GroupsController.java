package com.mcapanel.web.controllers;

import java.io.IOException;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

import com.mcapanel.web.database.Group;
import com.mcapanel.web.handlers.Controller;

public class GroupsController extends Controller
{
	public boolean canView()
	{
		return isLoggedIn() && user.getGroup().hasPermission("webusers");
	}
	
	public boolean index()
	{
		request.setAttribute("groups", arrayToString(getGroupsJson(true)));
		
		return renderView();
	}
	
	@SuppressWarnings("unchecked")
	private JSONArray getGroupsJson(boolean raw)
	{
		JSONArray groups = new JSONArray();
		
		List<Group> groupList = db.find(Group.class).findList();
		
		String b = raw ? "<td>" : "";
		String e = raw ? "</td>" : "";
		
		for (Group g : groupList)
		{
			JSONArray ar = new JSONArray();
			
			if (raw) ar.add("<tr>");
			ar.add(b + g.getId() + e);
			ar.add(b + "<span class=\"groupname\">" + g.getGroupName() + "</span>" + e);
			ar.add(b + "<input class=\"ghostcheck\" type=\"checkbox\" " + (g.isGhost() ? "checked" : "") + " /><span class=\"label label-" + (g.isGhost() ? "success\">true" : "danger\">false") + "</span>" + e);
			ar.add(b + "<input class=\"existingradio\" type=\"radio\" " + (g.isExistingDefault() ? "checked" : "") + " /><span class=\"label label-" + (g.isExistingDefault() ? "success\">true" : "danger\">false") + "</span>" + e);
			ar.add(b + "<input class=\"whitelistradio\" type=\"radio\" " + (g.isWhitelistDefault() ? "checked" : "") + " /><span class=\"label label-" + (g.isWhitelistDefault() ? "success\">true" : "danger\">false") + "</span>" + e);
			ar.add(b + "<span class=\"groupperms\">" + g.getPermissions() + "</span>" + e);
			if (raw) ar.add("</tr>");
			
			groups.add(ar);
		}
		
		return groups;
	}
	
	@SuppressWarnings("unchecked")
	public boolean saveGroups() throws IOException
	{
		if (isMethod("POST"))
		{
			includeIndex(false);
			mimeType("application/json");
			
			JSONObject obj = new JSONObject();
			
			if (canView())
			{
				String data = request.getParameter("data");
				
				if (data != null)
				{
					JSONArray groups = (JSONArray) JSONValue.parse(data);
					
					for (Object g : groups)
					{
						JSONObject group = (JSONObject) g;
						
						int id = Integer.parseInt(group.get("id").toString());
						String name = group.get("name").toString();
						boolean ghost = (Boolean) group.get("ghost");
						boolean existing = (Boolean) group.get("existing");
						boolean whitelist = (Boolean) group.get("whitelist");
						String permissions = group.get("permissions").toString();
						
						Group gr = db.find(Group.class, id);
						
						if (gr != null)
						{
							gr.setGroupName(name);
							gr.setGhost(ghost);
							gr.setExistingDefault(existing);
							gr.setWhitelistDefault(whitelist);
							gr.setPermissions(permissions);
							
							db.save(gr);
						}
					}
					
					obj.put("good", "Successfully saved all group settings.");
				} else
					obj.put("error", "Error parsing your request.");
			} else
				obj.put("error", "You do not have permission to do that.");
			
			response.getWriter().println(obj.toJSONString());
			
			return true;
		}
		
		return error();
	}
}