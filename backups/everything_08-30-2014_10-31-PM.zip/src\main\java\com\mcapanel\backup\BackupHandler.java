package com.mcapanel.backup;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import org.apache.commons.io.FileUtils;

import com.mcapanel.panel.AdminPanelWrapper;
import com.mcapanel.panel.ServerStatus;
import com.mcapanel.web.database.Backup;
import com.mcapanel.web.database.BackupSchedule;

public class BackupHandler
{
	private AdminPanelWrapper ap;
	
	private File mainDir;
	private File backupsDir;
	
	public BackupHandler(AdminPanelWrapper ap)
	{
		this.ap = ap;
		
		mainDir = ap.getServerJar().getParentFile();
		
		backupsDir = new File(mainDir, "backups");
		
		List<Backup> backups = ap.getDatabase().find(Backup.class).findList();
		
		for (Backup b : backups)
		{
			File f = new File(backupsDir, b.getFilename());
			
			if (!f.exists())
			{
				ap.getDatabase().delete(b);
				
				System.out.println("Could not find backup, removing from db");
			}
		}
	}
	
	
	
	public void runSchedules()
	{
		List<BackupSchedule> scheds = ap.getDatabase().find(BackupSchedule.class).findList();
		
		for (BackupSchedule bs : scheds)
		{
			BackupInterval.Interval i = BackupInterval.Interval.getFromString(bs.getIntervalString());
			
			long nextBackup = bs.getLastBackup() + (bs.getInterval() * i.getMult());
			
			SimpleDateFormat sdf = new SimpleDateFormat("MMM d, yyyy h:mm a");
			
			if (System.currentTimeMillis() >= nextBackup)
			{
				System.out.println("Backup " + bs.getDescription() + " is overdue, backing up");
				System.out.println("Supposed to be on " + sdf.format(new Date(nextBackup)));
				
				backupNow(bs);
				
				return;
			}
			
			scheduleBackup(bs);
		}
	}
	
	private void scheduleBackup(final BackupSchedule bsTemp)
	{
		BackupInterval.Interval i = BackupInterval.Interval.getFromString(bsTemp.getIntervalString());
		
		long nextBackup = bsTemp.getLastBackup() + (bsTemp.getInterval() * i.getMult());
		long backupTime = nextBackup - System.currentTimeMillis();
		
		backupTime = backupTime >= 0 ? backupTime : 0;
		
		new Timer().schedule(new TimerTask() {
			public void run()
			{
				BackupSchedule bs = ap.getDatabase().find(BackupSchedule.class, bsTemp.getId());
				
				if (bs != null)
				{
					backupNowRaw(bs);
				}
			}
		}, backupTime);
	}
	
	public void backupNow(final BackupSchedule schedule)
	{
		new Thread(new Runnable() {
			public void run()
			{
				backupNowRaw(schedule);
			}
		}).start();
	}
	
	public void backupNowRaw(BackupSchedule schedule)
	{
		System.out.println("Backing up " + schedule.getDescription());
		
		boolean backedUp = false;
		
		String filename = "";
		
		SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy_hh-mm-a");
		Date date = new Date();
		
		if (schedule.isBackupEverything())
		{
			try
			{
				filename = "everything_" + sdf.format(date) + ".zip";
				
				zipDir(new File(backupsDir, filename), new File[] { mainDir });
				
				backedUp = true;
			} catch (Exception e)
			{
				e.printStackTrace();
			}
		} else if (schedule.isBackupPlugins())
		{
			try
			{
				filename = "plugins_" + sdf.format(date) + ".zip";
				
				zipDir(new File(backupsDir, filename), new File[] { new File(mainDir, "plugins") });
				
				backedUp = true;
			} catch (Exception e)
			{
				e.printStackTrace();
			}
		} else if (schedule.isBackupWorlds())
		{
			List<File> worlds = new ArrayList<File>();
			
			String[] split = schedule.getWorlds().split(";");
			
			String ws = "";
			
			for (String s : split)
			{
				if (!s.isEmpty())
				{
					worlds.add(new File(mainDir, s));
					
					ws += s + ",";
				}
			}
			
			try
			{
				filename = ws + sdf.format(date) + ".zip";
				
				zipDir(new File(backupsDir, filename), worlds.toArray(new File[worlds.size()]));
				
				backedUp = true;
			} catch (Exception e)
			{
				e.printStackTrace();
			}
		}
		
		if (backedUp)
		{
			schedule.setLastBackup(date.getTime());
			
			Backup backup = new Backup(schedule.getId(), schedule.getDescription(), filename);
			
			ap.getDatabase().save(backup);
			ap.getDatabase().update(schedule);
			
			System.out.println("Successfully backed up " + schedule.getDescription());
		} else
			System.out.println("Could not backup " + schedule.getDescription());
		
		scheduleBackup(schedule);
	}
	
	public void restoreBackup(final Backup backup)
	{
		new Thread(new Runnable() {
			public void run()
			{
				System.out.println("Restoring backup " + backup.getDescription());
				
				File backupFile = new File(backupsDir, backup.getFilename());
				
				if (backupFile.exists())
				{
					if (ap.getStatus() != ServerStatus.STOPPED)
					{
						ap.stopBukkitServerRaw(false);
					}
					
					if (ap.getStatus() == ServerStatus.STOPPED)
					{
						try
						{
							BackupSchedule bs = ap.getDatabase().find(BackupSchedule.class, backup.getSchedule());
							
							if (bs != null)
							{
								System.out.println("Backing up, just in case you don't like the previous backup");
								
								backupNowRaw(bs);
							}
							
							unzipFile(backupFile, mainDir);
							
							System.out.println("Successfully restored " + backup.getDescription());
						} catch (IOException e)
						{
							e.printStackTrace();
						}
					} else
						System.out.println("Invalid server state for restoring backup, please try again");
				} else
					System.out.println("Could not find backup " + backup.getDescription() + ", aborting restore");
			}
		}).start();
	}
	
	public boolean deleteBackup(Backup backup)
	{
		File backupFile = new File(backupsDir, backup.getFilename());
		
		if (backupFile.exists())
		{
			boolean deleted = backupFile.delete();
			
			if (deleted)
			{
				System.out.println("Deleted backup " + backup.getFilename());
				
				return true;
			}
		}
		
		return false;
	}
	
	private void zipDir(File zipFile, File[] dir) throws Exception
	{
		zipFile.getParentFile().mkdirs();
		
		ZipOutputStream out = new ZipOutputStream(new FileOutputStream(zipFile));
		
		for (File f : dir)
		{
			addDir(f, out);
		}
		
		out.close();
	}
	
	private void addDir(File dirObj, ZipOutputStream out) throws IOException
	{
		File[] files = dirObj.listFiles();
		byte[] tmpBuf = new byte[1024];
		
		for (int i = 0; i < files.length; i++)
		{
			if (files[i].isDirectory())
			{
				if (!files[i].getName().equals("backups") && !files[i].getName().equals("logs") && !files[i].getName().equals("target") && !files[i].getName().equals("McAdminPanel"))
					addDir(files[i], out);
				
				continue;
			}
			
			if (!files[i].exists())
				continue;
			
			FileInputStream in = new FileInputStream(files[i].getAbsolutePath());
			
			out.putNextEntry(new ZipEntry(files[i].getAbsolutePath().replace(mainDir.getAbsolutePath().replace(".", "") + File.separator, "")));
			
			int len;
			while ((len = in.read(tmpBuf)) > 0)
			{
				out.write(tmpBuf, 0, len);
			}
			
			out.closeEntry();
			in.close();
		}
	}
	
	private void unzipFile(File zipFile, File dir) throws IOException
	{
		ZipInputStream in = new ZipInputStream(new FileInputStream(zipFile));
		
		ZipEntry ze = in.getNextEntry();
		
		byte[] buffer = new byte[1024];
		
		while (ze != null)
		{
			File f = new File(dir, ze.getName());
			
			if (f.isDirectory() && f.exists())
			{
				FileUtils.deleteDirectory(f);
			} else if (f.exists())
			{
				f.delete();
			}
			
			FileOutputStream fos = new FileOutputStream(f);
			 
            int len;
            
            while ((len = in.read(buffer)) > 0)
            {
            	fos.write(buffer, 0, len);
            }
            
            fos.close();
			
			ze = in.getNextEntry();
		}
		
		in.closeEntry();
		in.close();
	}
}