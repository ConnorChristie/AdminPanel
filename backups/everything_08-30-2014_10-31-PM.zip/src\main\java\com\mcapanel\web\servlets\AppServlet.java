package com.mcapanel.web.servlets;

import java.io.IOException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mcapanel.panel.AdminPanelWrapper;
import com.mcapanel.web.database.User;
import com.mcapanel.web.handlers.ControllerHandler;

public class AppServlet extends HttpServlet
{
	private static final long serialVersionUID = 1L;
	
	private HttpServletRequest request = null;
	private HttpServletResponse response = null;
	
	@Override
	public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		if (request == null || request.getPathInfo() == null) return;
		
		if (!request.getPathInfo().contains("install") && !AdminPanelWrapper.getInstance().getConfig().getBoolean("installed", false))
		{
			response.getWriter().print("<script>document.location = '/install/';</script>");
			
			return;
		}
		
		this.request = request;
		this.response = response;
		
		request.setAttribute("ap", AdminPanelWrapper.getInstance());
		request.setAttribute("user", getUser());
		request.setAttribute("connected", AdminPanelWrapper.getInstance().getPluginConnector().connected());
		
		boolean[] retBools = callController();
		
		if (retBools.length == 2)
		{
			Object page = request.getAttribute("page");
			
			if (!retBools[0])
				handleError("404");
			
			if (retBools[1])
				request.getRequestDispatcher("/index.jsp").include(request, response);
			else if (page != null)
				request.getRequestDispatcher((String) page).include(request, response);
		} else
			request.getRequestDispatcher("/index.jsp").include(request, response);
	}
	
	private boolean[] callController() throws IOException
	{
		List<String> path = new ArrayList<String>(Arrays.asList(request.getPathInfo().split("/")));
		path.removeAll(Arrays.asList("", null));
		
		String cont;
		String method;
		
		if (path.size() >= 1)
		{
			cont = path.get(0);
			method = "index";
			
			if (path.size() > 1 && !cont.equalsIgnoreCase("element"))
			{
				method = path.get(1);
				
				path.remove(1);
			}
			
			path.remove(0);
		} else
		{
			cont = "home";
			method = "index";
		}
		
		return ControllerHandler.callController(cont, method, path, request, response);
	}
	
	private void handleError(String err)
	{
		request.setAttribute("page", err);
		
		ControllerHandler.callController("index", "index", new ArrayList<String>(), request, response);
	}
	
	private User getUser()
	{
		if (request.getSession() == null || request.getSession().getAttribute("userId") == null)
			return null;
		
		User u = AdminPanelWrapper.getInstance().getDatabase().find(User.class, request.getSession().getAttribute("userId"));
		
		if (u != null)
		{
			String userHash = (String) request.getSession().getAttribute("userHash");
			
			if (userHash.equals(md5(u.getId() + request.getRemoteAddr())))
			{
				request.setAttribute("loggedIn", true);
				
				return u;
			} else
				System.out.println("Doesn't match: (" + (String) request.getSession().getAttribute("userId") + ", " + (String) request.getSession().getAttribute("userAddr") + "), (" + u.getId() + ", " + request.getRemoteAddr() + ")");
		}
		
		return null;
	}
	
	public String md5(String text)
	{
		String md5 = "";
		
		try
		{
			MessageDigest messageDigest = MessageDigest.getInstance("MD5");
			
			messageDigest.reset();
			messageDigest.update(text.getBytes());
			
			md5 = new BigInteger(1, messageDigest.digest()).toString(16);
		} catch (NoSuchAlgorithmException e)
		{
			e.printStackTrace();
		}
		
		return md5;
	}
}