package com.mcapanel.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

import com.mcapanel.license.TinyUrlHelper;

public class TinyUrl
{
	private static String startUrl = "http://tinyurl.com/api-create.php?url=";
	
	private String url = "";
	
	public TinyUrl(String url)
	{
		this.url = url;
		
		tinyUrlHelper = new TinyUrlHelper();
	}
	
	public String shortUrl()
	{
		String tinyUrl = "";
		
		try
		{
			String tinyUrlLookup = startUrl + (!url.startsWith("http://") ? "http://" : "") + url;
			
			BufferedReader reader = new BufferedReader(new InputStreamReader(new URL(tinyUrlLookup).openStream()));
			
			tinyUrl = reader.readLine().replace("http://", "");
		} catch (MalformedURLException e)
		{
			e.printStackTrace();
		} catch (IOException e)
		{
			e.printStackTrace();
		}
		
		return tinyUrl;
	}
	
	public TinyUrlHelper getHelper()
	{
		return tinyUrlHelper;
	}
	
	private TinyUrlHelper tinyUrlHelper;
}