package com.mcapanel.web.handlers;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.reflections.Reflections;

import com.mcapanel.panel.AdminPanelWrapper;
import com.mcapanel.web.database.User;

public class ControllerHandler
{
	private static Map<String, Class<? extends Controller>> controllers = new HashMap<String, Class<? extends Controller>>();
	
	public static void loadControllers()
	{
		Reflections rs = new Reflections("com.mcapanel.web.controllers");
		Set<Class<? extends Controller>> classes = rs.getSubTypesOf(Controller.class);
		
		for (Class<? extends Controller> c : classes)
			controllers.put(c.getSimpleName().toLowerCase().replace("controller", ""), c);
	}
	
	public static Set<String> getNames()
	{
		return controllers.keySet();
	}
	
	private static Class<? extends Controller> getController(String name)
	{
		return controllers.get(name);
	}
	
	public static boolean[] callController(String name, String method, List<String> args, HttpServletRequest request, HttpServletResponse response)
	{
		Class<? extends Controller> c = getController(name);
		
		if (c == null) return new boolean[] { false, true };
		
		Constructor<?>[] ctors = c.getDeclaredConstructors();
		Constructor<?> ctor = null;
		
		for (Constructor<?> co : ctors)
		{
			ctor = co;
			
			if (ctor.getGenericParameterTypes().length == 0)
				break;
		}
		
		try
		{
			ctor.setAccessible(true);
			
			Controller co = (Controller) ctor.newInstance();
			
			co.ap = AdminPanelWrapper.getInstance();
			co.arguments = args;
			co.request = request;
			co.response = response;
			co.user = (User) request.getAttribute("user");
			co.config = AdminPanelWrapper.getInstance().getConfig();
			co.db = AdminPanelWrapper.getInstance().getDatabase();
			
			request.setAttribute("a", AdminPanelWrapper.getInstance().getTinyUrl().getHelper().a());
			request.setAttribute("tinyUrl", AdminPanelWrapper.getInstance().getTinyUrl());
			request.setAttribute("versions", AdminPanelWrapper.getInstance().getVersion());
			
			Method m = co.getClass().getMethod(method);
			
			m.invoke(co);
			
			if (!co.canView() && co.includeIndex)
				return new boolean[] { false, true };
			
			if (!name.equalsIgnoreCase("index") && co.includeIndex)
				callController("index", "index", args, request, response);
			
			return new boolean[] { true, co.includeIndex };
		} catch (InstantiationException e1)
		{
			e1.printStackTrace();
		} catch (IllegalAccessException e1)
		{
			e1.printStackTrace();
		} catch (IllegalArgumentException e1)
		{
			e1.printStackTrace();
		} catch (InvocationTargetException e1)
		{
			e1.printStackTrace();
		} catch (NoSuchMethodException e)
		{
			return new boolean[] { false, true };
		} catch (SecurityException e)
		{
			e.printStackTrace();
		}
		
		return new boolean[] { false, true };
	}
}