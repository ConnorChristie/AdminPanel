var clickedObject;
var contextClick;

var unloading = false;

var cpuPlot;
var ramPlot;

var cpuSeries;
var ramSeries;

var cpuGraphData = [];
var ramGraphData = [];

function updateCpuGraph(val)
{
	if (cpuGraphData.length > 100)
	{
		cpuGraphData = cpuGraphData.slice(1);
	}
	
	cpuGraphData.push(val);
	
	var res = [];
	
	for (var i = 100; i >= 0; i--)
	{
		res.push([100 - i, cpuGraphData[cpuGraphData.length - i - 1]]);
	}

	return res;
}

function updateRamGraph(val)
{
	if (ramGraphData.length > 100)
	{
		ramGraphData = ramGraphData.slice(1);
	}
	
	ramGraphData.push(val);
	
	var res = [];
	
	for (var i = 100; i >= 0; i--)
	{
		res.push([100 - i, ramGraphData[ramGraphData.length - i - 1]]);
	}

	return res;
}

$(function() {
	var $contextMenu = $("#contextMenu");
	
	var drawn = false;
	var foundId = false;
	
	if ($("#cpuchart").length)
	{
		var container = $("#cpuchart");
		
		cpuSeries = [{
			data: [],
			lines: {
				fill: true
			}
		}];
	
		cpuPlot = $.plot(container, cpuSeries, {
			grid: {
				borderWidth: 1,
				minBorderMargin: 0,
				labelMargin: 10,
				backgroundColor: {
					colors: ["#fff", "#e4f4f4"]
				},
				margin: {
					top: 0,
					bottom: 0,
					left: 10,
					right: 20
				},
				markings: function(axes) {
					var markings = [];
					var xaxis = axes.xaxis;
					
					for (var x = Math.floor(xaxis.min); x < xaxis.max; x += xaxis.tickSize * 2)
					{
						markings.push({ xaxis: { from: x, to: x + xaxis.tickSize }, color: "rgba(232, 232, 255, 0.2)" });
					}
					
					return markings;
				}
			},
			xaxis: {
				min: 0,
				max: 100,
				tickFormatter: function() {
					return "";
				}
			},
			yaxis: {
				min: 0,
				max: 100
			}
		});
	}
	
	if ($("#ramchart").length)
	{
		var container = $("#ramchart");
		
		ramSeries = [{
			data: [],
			lines: {
				fill: true
			}
		}];
	
		ramPlot = $.plot(container, ramSeries, {
			grid: {
				borderWidth: 1,
				minBorderMargin: 0,
				labelMargin: 10,
				backgroundColor: {
					colors: ["#fff", "#e4f4f4"]
				},
				margin: {
					top: 0,
					bottom: 10,
					left: 10,
					right: 20
				},
				markings: function(axes) {
					var markings = [];
					var xaxis = axes.xaxis;
					
					for (var x = Math.floor(xaxis.min); x < xaxis.max; x += xaxis.tickSize * 2)
					{
						markings.push({ xaxis: { from: x, to: x + xaxis.tickSize }, color: "rgba(232, 232, 255, 0.2)" });
					}
					
					return markings;
				}
			},
			xaxis: {
				min: 0,
				max: 100,
				tickFormatter: function() {
					return "";
				}
			},
			yaxis: {
				min: 0,
				max: 100
			}
		});
	}
	
	$("#nav").children("li").each(function() {
		if (window.location.pathname.indexOf((this.id == "/players" ? "/player" : (this.id == "/plugins" ? "/plugin" : this.id))) >= 0)
		{
			foundId = true;
			
			$("#" + this.id).addClass("active");
		} else if (window.location.pathname == "/" || window.location.pathname == "/index.html")
		{
			$("#home").addClass("active");
		} else if (window.location.pathname.indexOf("/groups") >= 0 || window.location.pathname.indexOf("/users") >= 0)
		{
			$("#webTab").addClass("active");
		}
	});
	
	if (!foundId && window.location.pathname != "/"  && window.location.pathname != "/index.html")
		$("#home").removeClass("active");
	
	$("#oplayertable tbody").on("click", "tr", function(e) {
		clickPlayer($(this), e);
		
		return false;
	});
	
	resize();
	
	$(window).resize(function() {
		resize();
	});
	
	$(document).click(function () {
		if (!contextClick)
		{
			$contextMenu.css({
				display: "none"
			});
		}
		
		contextClick = false;
	});
	
	$("#loginForm").submit(function(e) {
		e.preventDefault();
		
		$.ajax({
			type: "post",
			url: "/user/login/",
			data: {"username":$("#loginForm").find("#username").val(), "password":$("#loginForm").find("#password").val()},
			success: function(data) {
				if (data.good != undefined)
				{
					document.location = $("#loginForm").attr("action");
				} else if (data.error != undefined)
				{
					errorModal(data.error);
				}
			}
		});
	});
	
	$("#chatform").submit(function(e) {
		e.preventDefault();
		
		if ($("#messages").css("display") == "block")
		{
			issueChat();
		} else if ($("#console").css("display") == "block")
		{
			issueCommand();
		}
	});
	
	var which = $.cookie("messagesconsole");
	
	if (which == undefined)
		$.cookie("messagesconsole", "messages", { expires: 7, path: '/' });
	
	if ($("#console").length == 0 || $("#console").text().trim() == "${console}")
		$.cookie("messagesconsole", "messages", { expires: 7, path: '/' });
	
	which = $.cookie("messagesconsole");
	
	if (which == "console" && $("#console").length != 0)
	{
		$("#messages").css({"display":"none"});
		$("#console").css({"display":"block"});
		
		$("#chatmsg").attr("placeholder", "Console Command");
		$("#chatbtn").text("Send");
		
		$("#console").parent().css({"background-color":"black"});
		
		$("#server li.active").removeClass("active");
		$("#consolebutton").addClass("active");
		
		var height = $("#console")[0].scrollHeight;
		$("#console").scrollTop(height);
	} else
		$.cookie("messagesconsole", "messages", { expires: 7, path: '/' });
	
	$("#server a").click(function(e) {
		var oldId = $("#" + $("#server li.active a").attr("forid"));
		var newId = $("#" + $(this).attr("forid"));
		
		$("#server li.active").removeClass("active");
		$(this).parent().addClass("active");
		
		oldId.slideUp(function() {
			newId.slideDown(function() {
				var height = newId[0].scrollHeight;
				newId.scrollTop(height);
				
				resize();
			});
		});
		
		if ($(this).attr("forid") == "console")
		{
			$("#chatmsg").attr("placeholder", "Console Command");
			$("#chatbtn").text("Send");
			
			$(this).parent().parent().parent().parent().parent().find(".panel-body").css({"background-color":"black"});
		} else if ($(this).attr("forid") == "messages")
		{
			$("#chatmsg").attr("placeholder", "Chat Message");
			$("#chatbtn").text("Chat");
			
			$(this).parent().parent().parent().parent().parent().find(".panel-body").css({"background-color":"white"});
		}
		
		$.cookie("messagesconsole", $(this).attr("forid"), { expires: 7, path: '/' });
		
		return false;
	});
	
	if ($("#messages").text().indexOf("No Chats") >= 0)
		$("#messages").css({"text-align": "center"});
	else
		$("#messages").css({"text-align": "left"});
	
	if ($("#console").text().indexOf("No Console Data") >= 0)
		$("#console").css({"text-align": "center"});
	else
		$("#console").css({"text-align": "left"});
	
	var msgs = $("#messages");
	
	if (msgs.length > 0)
	{
		var height = msgs[0].scrollHeight;
		
		msgs.scrollTop(height);
	}
	
	if (window.location.pathname.indexOf("install") < 0)
		loadEverything();
});

function issueChat()
{
	$.post("/event/issueChat", {chatmsg: $("#chatmsg").val()}, function(data) {
		if (data.error != undefined)
			errorModal(data.error);
		
		$("#chatmsg").val("");
		$("#messages").html(data.chats);
		
		var msgs   = $('#messages');
		var height = msgs[0].scrollHeight;
		
		msgs.scrollTop(height);
		
		if ($("#messages").text().indexOf("No Chats") >= 0)
			$("#messages").css({"text-align": "center"});
		else
			$("#messages").css({"text-align": "left"});
	});
}

function issueCommand()
{
	$.post("/event/issueCommand", {command: $("#chatmsg").val()}, function(data) {
		if (data.error != undefined)
			errorModal(data.error);
		
		$("#chatmsg").val("");

		if (data.console != undefined)
		{
			$("#console").html("<pre>" + data.console + "</pre>");
			
			var msgs   = $('#console');
			var height = msgs[0].scrollHeight;
			
			msgs.scrollTop(height);
			
			if ($("#console").text().indexOf("No Console Data") >= 0)
				$("#console").css({"text-align": "center"});
			else
				$("#console").css({"text-align": "left"});
		}
	});
}

function loadEverything()
{
	var oldChats   = $("#messages").html();
	var oldConsole = $("#console").html();
	
	if (!unloading)
	{
		$.ajax("/event/getEverything", {
			type: 'GET',
			timeout: 5000,
			success: function(data) {
				if (data.usage != undefined)
				{
					$("#ramtotal").html("<b>Total: " + data.usage.ramTotal + " GB</b>");
					$("#ramused").html("<b>Used: " + data.usage.ramUsed + " GB</b>");
					$("#ramfree").html("<b>Free: " + data.usage.ramFree + " GB</b>");
					
					$("#cpucores").html("<b>Cores: " + data.usage.cpuCores + "</b>");
					$("#cpufreq").html("<b>Frequency: " + data.usage.cpuFreq + " GHz</b>");
					
					$("#ramcircle").val(data.usage.ramPercent).trigger("change");
					$("#cpucircle").val(data.usage.cpuPercent).trigger("change");
					
					if ($("#cpuchart").length)
					{
						cpuSeries[0].data = updateCpuGraph(data.usage.cpuPercent);
						
						cpuPlot.setData(cpuSeries);
						cpuPlot.draw();
					}
					
					if ($("#ramchart").length)
					{
						ramSeries[0].data = updateRamGraph(data.usage.ramPercent);
						
						ramPlot.setData(ramSeries);
						ramPlot.draw();
					}
					
					var disks = data.usage.disks;
					
					for (var i = 0; i < disks.length; i++)
					{
						var disk = disks[i];
						
						$("#disk" + i + "title").html("<b>Disk " + i + "</b>");
						$("#disk" + i + "total").html("<b>Total: " + disk.diskTotal + " GB</b>");
						$("#disk" + i + "used").html("<b>Used: " + disk.diskUsed + " GB</b>");
						$("#disk" + i + "free").html("<b>Free: " + disk.diskFree + " GB</b>");
						
						$("#disk" + i + "circle").val(disk.diskPercent).trigger("change");
					}
				}
				
				if (data.control != undefined)
				{
					var control = data.control;
					
					$("#statusTitle").html(control.statusTitle);
					
					if (control.startServer)
						$("#startServer").removeAttr("disabled");
					else
						$("#startServer").attr("disabled", "");
					
					if (control.stopServer)
						$("#stopServer").removeAttr("disabled");
					else
						$("#stopServer").attr("disabled", "");
					
					if (control.restartServer)
						$("#restartServer").removeAttr("disabled");
					else
						$("#restartServer").attr("disabled", "");
					
					if (control.reloadServer)
						$("#reloadServer").removeAttr("disabled");
					else
						$("#reloadServer").attr("disabled", "");
				}
				
				$("#messages").html(data.chats);
				$("#console").html("<pre>" + data.console + "</pre>");
				
				$("#status").html(data.playersObj.status);
				
				$("#playerson").html(data.playersObj.plist);
				$("#ponline").text(data.playersObj.online + " / " + data.playersObj.total);
				
				if (oldChats != $("#messages").html())
				{
					var msgs   = $('#messages');
					var height = msgs[0].scrollHeight;
					
					msgs.scrollTop(height);
				}
				
				if (oldConsole != $("#console").html())
				{
					var msgs   = $('#console');
					var height = msgs[0].scrollHeight;
					
					msgs.scrollTop(height);
				}
				
				if ($("#messages").text().indexOf("No Chats") >= 0)
					$("#messages").css({"text-align": "center"});
				else
					$("#messages").css({"text-align": "left"});
					
				if ($("#console").text().indexOf("No Console Data") >= 0)
					$("#console").css({"text-align": "center"});
				else
					$("#console").css({"text-align": "left"});
					
				setTimeout(loadEverything, 750);
			},
			error: function(xhr, ajaxOptions, thrownError) {
				/*
				$("#status").html("<span style=\"color: red;\">Offline</span>");
				$("#statusTitle").html("<span style=\"color: red;\">Stopped: " + xhr.status + "</span>");
				
				$("#ponline").text("0 / 0");
				$("#playerson").html("");
				
				$("#startServer").attr("disabled", "");
				$("#stopServer").attr("disabled", "");
				$("#restartServer").attr("disabled", "");
				$("#reloadServer").attr("disabled", "");
				*/
				
				setTimeout(loadEverything, 2000);
			}
		});
	}
}

function resize()
{
	//$("body").css({"height": window.outerHeight});
	//$(".carousel .item").css({"height": window.outerHeight});
	
	$("#chatmsg").css({"width": $("#chatmsg").parent().width() - 68});
}