package com.mcapanel.web.controllers;

import java.io.IOException;
import java.io.OutputStream;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

import com.mcapanel.panel.AdminPanelWrapper;
import com.mcapanel.web.database.Group;
import com.mcapanel.web.handlers.Controller;

@SuppressWarnings("unchecked")
public class EventController extends Controller
{
	public boolean getEverything() throws IOException
	{
		includeIndex(false);
		mimeType("application/json");
		
		JSONObject out = new JSONObject();
		
		if (isLoggedIn())
		{
			if (user.getGroup().hasPermission("usage"))
				out.put("usage", ap.getUsages().getUsageJson());
			
			if (user.getGroup().hasPermission("control"))
				out.put("control", HomeController.getControlsJson());
			
			if (user.getGroup().hasPermission("console"))
				out.put("console", IndexController.getConsole());
			else
				out.put("console", "No Console Data");
		} else
			out.put("console", "No Console Data");
		
		out.put("playersObj", IndexController.getOnlinePlayers());
		out.put("chats", IndexController.getChats());
		
		response.getWriter().println(out.toJSONString());
		
		return true;
	}
	
	public boolean issueChat() throws IOException
	{
		if (isMethod("POST"))
		{
			includeIndex(false);
			mimeType("application/json");
			
			JSONObject out = new JSONObject();
			
			if (isLoggedIn() && user.getGroup().hasPermission("chat"))
			{
				String chats = ap.getPluginConnector().sendMethodResponse("issueChat", user.getUsername(), request.getParameter("chatmsg"));
				
				out.put("chats", chats != null ? chats : "No Chats");
				
				out.put("good", "good");
			} else
				out.put("error", "You do not have permission to do that.");
			
			response.getWriter().println(out.toJSONString());
			
			return true;
		}
		
		return error();
	}
	
	public boolean issueCommand() throws IOException
	{
		if (isMethod("POST"))
		{
			includeIndex(false);
			mimeType("application/json");
			
			JSONObject obj = new JSONObject();
			
			if (isLoggedIn() && user.getGroup().hasPermission("console"))
			{
				OutputStream writer = AdminPanelWrapper.getInstance().getWriter();
				
				if (!ap.parseCommand(request.getParameter("command")))
				{
					try
					{
						writer.write((request.getParameter("command") + "\n").getBytes());
						writer.flush();
					} catch (IOException e) { }
				}
				
				obj.put("good", "good");
				obj.put("console", IndexController.getConsole());
			} else
				obj.put("error", "You do not have permission to do that.");
			
			response.getWriter().println(obj.toJSONString());
			
			return true;
		}
		
		return error();
	}
	
	public boolean saveGroups() throws IOException
	{
		if (isMethod("POST"))
		{
			includeIndex(false);
			mimeType("application/json");
			
			JSONObject obj = new JSONObject();
			
			if (isLoggedIn() && user.getGroup().hasPermission("webusers"))
			{
				String data = request.getParameter("data");
				
				if (data != null)
				{
					JSONArray groups = (JSONArray) JSONValue.parse(data);
					
					for (Object g : groups)
					{
						JSONObject group = (JSONObject) g;
						
						int id = Integer.parseInt(group.get("id").toString());
						String name = group.get("name").toString();
						boolean ghost = (Boolean) group.get("ghost");
						boolean existing = (Boolean) group.get("existing");
						boolean whitelist = (Boolean) group.get("whitelist");
						String permissions = group.get("permissions").toString();
						
						Group gr = db.find(Group.class, id);
						
						if (gr != null)
						{
							gr.setGroupName(name);
							gr.setGhost(ghost);
							gr.setExistingDefault(existing);
							gr.setWhitelistDefault(whitelist);
							gr.setPermissions(permissions);
							
							db.save(gr);
						}
					}
					
					obj.put("good", "Successfully saved all group settings.");
				} else
					obj.put("error", "Error parsing your request.");
			} else
				obj.put("error", "You do not have permission to do that.");
			
			response.getWriter().println(obj.toJSONString());
			
			return true;
		}
		
		return error();
	}
	
	public boolean system() throws IOException
	{
		if (isMethod("POST"))
		{
			includeIndex(false);
			mimeType("application/json");
			
			JSONObject out = new JSONObject();
			
			if (isLoggedIn() && user.getGroup().hasPermission("control"))
			{
				if (arguments.size() == 1)
				{
					if (arguments.get(0).equalsIgnoreCase("startServer"))
					{
						ap.startBukkitServer();
						
						out.put("good", "Starting the server.");
					} else if (arguments.get(0).equalsIgnoreCase("stopServer"))
					{
						ap.stopBukkitServer(false);
						
						out.put("good", "Stopping the server.");
					} else if (arguments.get(0).equalsIgnoreCase("restartServer"))
					{
						ap.restartBukkitServer();
						
						out.put("good", "Restarting the server.");
					} else if (arguments.get(0).equalsIgnoreCase("reloadServer"))
					{
						ap.reloadBukkitServer();
						
						out.put("good", "Reloading the server.");
					}
				}
				
				out.put("control", HomeController.getControlsJson());
				
				out.put("error", "The command you are trying to issue doesn't exist.");
			} else
				out.put("error", "You do not have permission to do that.");
			
			response.getWriter().println(out.toJSONString());
			
			return true;
		}
		
		return error();
	}
}