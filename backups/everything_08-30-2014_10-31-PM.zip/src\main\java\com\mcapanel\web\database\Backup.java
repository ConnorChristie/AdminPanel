package com.mcapanel.web.database;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.avaje.ebean.validation.NotNull;

@Entity()
@Table(name = "backups")
public class Backup
{
	@Id
	private int id;
	
	private int schedule;
	
	@NotNull
	private String description;
	
	@NotNull
	private String filename;
	
	@NotNull
	private long date;
	
	public Backup() {}
	
	public Backup(int schedId, String description, String filename)
	{
		this.schedule = schedId;
		this.description = description;
		this.filename = filename;
		
		date = System.currentTimeMillis();
	}

	public int getId()
	{
		return id;
	}

	public void setId(int id)
	{
		this.id = id;
	}

	public int getSchedule()
	{
		return schedule;
	}

	public void setSchedule(int schedule)
	{
		this.schedule = schedule;
	}

	public String getDescription()
	{
		return description;
	}

	public void setDescription(String description)
	{
		this.description = description;
	}

	public String getFilename()
	{
		return filename;
	}

	public void setFilename(String filename)
	{
		this.filename = filename;
	}

	public long getDate()
	{
		return date;
	}

	public void setDate(long date)
	{
		this.date = date;
	}
}
